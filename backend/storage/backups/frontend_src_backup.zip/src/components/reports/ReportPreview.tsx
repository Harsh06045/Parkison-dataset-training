import React from "react";
import {
  Printer,
  Download,
  ShieldCheck,
  Stethoscope,
  CheckCircle,
  Brain,
  Activity,
  Calendar,
  FileCheck2,
  Share2,
} from "lucide-react";
import { UnifiedDiagnosticReport } from "@/services/reportApi";

interface ReportPreviewProps {
  report: UnifiedDiagnosticReport;
  onClose?: () => void;
}

export function ReportPreview({ report, onClose }: ReportPreviewProps) {
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    const textContent = `========================================================================
NEUROFUSION AI CLINICAL DIAGNOSTIC REPORT
Document ID: ${report.id}
Generated: ${report.createdAt}
Hospital: ${report.hospitalName}
========================================================================

PATIENT INFORMATION:
- Name: ${report.patientName}
- Patient ID: ${report.patientId}
- Age / Gender: ${report.patientAge} Years / ${report.patientGender}
- Attending Physician: ${report.doctorName} (License: ${report.doctorLicense})

DIAGNOSTIC SUMMARY:
- Disease Evaluated: ${report.disease}
- Modality / Input: ${report.modalityOrSource}
- Primary AI Classification: ${report.primaryDiagnosis}
- Confidence Score: ${report.confidenceScore.toFixed(1)}%

KEY QUANTITATIVE FINDINGS:
${report.keyFindings.map((f, i) => `${i + 1}. ${f}`).join("\n")}

AI EXPLAINABILITY ANALYSIS (${report.explainabilitySummary.method}):
${report.explainabilitySummary.topFactors.map((f) => `• ${f.name}: ${f.value} [${f.impact}]`).join("\n")}

RECOMMENDED CLINICAL CARE PLAN:
${report.recommendations.map((r, i) => `${i + 1}. ${r}`).join("\n")}

========================================================================
LEGAL & CLINICAL DISCLAIMER:
${report.disclaimer}
========================================================================`;

    const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Diagnostic_Report_${report.patientName.replace(/\s+/g, "_")}_${report.id}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const isAlz = report.disease === "Alzheimer's Disease";

  return (
    <div className="space-y-6 text-[#0b1c30] select-none">
      {/* Top Action Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4 print:hidden">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 shadow-sm">
            <FileCheck2 className="size-5" />
          </div>
          <div>
            <h2 className="font-headline text-base font-bold text-[#0b1c30] tracking-tight">Clinical Diagnostic Report</h2>
            <p className="text-xs text-[#64748b]">
              Report ID: <span className="font-mono text-[#0ea5e9] font-bold">{report.id}</span> • {report.createdAt}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="btn-secondary py-2 px-3.5"
          >
            <Printer className="size-3.5" />
            <span>Print Report</span>
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="btn-primary py-2 px-4"
          >
            <Download className="size-3.5" />
            <span>Export File</span>
          </button>
        </div>
      </div>

      {/* Formal Medical Diagnostic Report Body (Clean, high-contrast, clinical) */}
      <div className="rounded-3xl border border-[#e2e8f0] bg-white p-6 sm:p-10 shadow-card space-y-8 text-xs text-[#475569] print:shadow-none print:border-none print:p-0">
        {/* Hospital Branding Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-6">
          <div className="flex items-center gap-3">
            <div className="flex size-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#0b1c30] to-[#0ea5e9] text-white font-extrabold shadow-md">
              <Brain className="size-6" />
            </div>
            <div>
              <h1 className="font-headline text-lg font-black text-[#0b1c30] tracking-tight">
                {report.hospitalName}
              </h1>
              <p className="text-xs text-[#64748b]">
                Department of Neurological Informatics &amp; Computational Neurosciences
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <span className="rounded-full bg-emerald-50 border border-emerald-200 px-3 py-0.5 text-xs font-bold text-emerald-700">
              {report.status}
            </span>
            <p className="text-[0.7rem] font-mono text-[#64748b] mt-1">
              Doc ID: {report.id}
            </p>
          </div>
        </div>

        {/* Patient & Doctor Demographics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 rounded-2xl border border-[#e2e8f0] bg-[#f8f9ff] p-5">
          <div>
            <p className="text-[0.65rem] uppercase font-bold text-[#64748b]">Patient Full Name</p>
            <p className="text-sm font-bold text-[#0b1c30] mt-0.5">{report.patientName}</p>
          </div>
          <div>
            <p className="text-[0.65rem] uppercase font-bold text-[#64748b]">Patient ID</p>
            <p className="text-sm font-mono font-bold text-[#0ea5e9] mt-0.5">{report.patientId}</p>
          </div>
          <div>
            <p className="text-[0.65rem] uppercase font-bold text-[#64748b]">Attending Physician</p>
            <p className="text-xs font-semibold text-[#0b1c30] mt-0.5">{report.doctorName}</p>
            <p className="text-[0.62rem] font-mono text-[#64748b]">{report.doctorLicense}</p>
          </div>
          <div>
            <p className="text-[0.65rem] uppercase font-bold text-[#64748b]">Evaluation Date</p>
            <p className="text-xs font-mono text-[#0b1c30] mt-0.5">{report.createdAt}</p>
          </div>
        </div>

        {/* Primary AI Diagnosis Highlight Box */}
        <div
          className={`rounded-2xl border p-5 space-y-1 ${
            isAlz
              ? "border-purple-200 bg-purple-50/70"
              : "border-cyan-200 bg-cyan-50/70"
          }`}
        >
          <div className="flex items-center justify-between">
            <span
              className={`text-[0.68rem] uppercase font-extrabold tracking-wider ${
                isAlz ? "text-purple-700" : "text-cyan-700"
              }`}
            >
              Primary AI Diagnostic Assessment ({report.disease})
            </span>
            <span className="font-mono font-bold text-xs text-[#0b1c30]">
              AI Confidence: {report.confidenceScore.toFixed(1)}%
            </span>
          </div>
          <h3 className="font-headline text-xl font-extrabold text-[#0b1c30]">{report.primaryDiagnosis}</h3>
          <p className="text-xs text-[#475569]">
            Ingested Modality: <strong className="text-[#0b1c30]">{report.modalityOrSource}</strong>
          </p>
        </div>

        {/* Key Clinical & Imaging Findings */}
        <div className="space-y-3">
          <h4 className="font-headline text-xs font-bold text-[#0b1c30] uppercase tracking-wider flex items-center gap-2">
            <CheckCircle className="size-4 text-[#0ea5e9]" />
            <span>Key Quantitative &amp; Biomarker Findings</span>
          </h4>
          <div className="rounded-2xl border border-[#e2e8f0] bg-[#f8f9ff] p-4 space-y-2.5">
            {report.keyFindings.map((finding, idx) => (
              <div key={idx} className="flex items-start gap-2.5">
                <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-[#0ea5e9] text-white text-[0.65rem] font-bold">
                  {idx + 1}
                </span>
                <p className="leading-relaxed text-[#0b1c30]">{finding}</p>
              </div>
            ))}
          </div>
        </div>

        {/* AI Explainability Section */}
        <div className="space-y-3">
          <h4 className="font-headline text-xs font-bold text-[#0b1c30] uppercase tracking-wider flex items-center gap-2">
            <Stethoscope className="size-4 text-purple-600" />
            <span>AI Explainability &amp; Feature Attribution ({report.explainabilitySummary.method})</span>
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {report.explainabilitySummary.topFactors.map((factor, idx) => (
              <div key={idx} className="p-3.5 rounded-xl border border-[#e2e8f0] bg-[#f8f9ff]">
                <p className="font-bold text-xs text-[#0b1c30] truncate">{factor.name}</p>
                <p className="text-[0.68rem] font-mono text-[#0ea5e9] mt-1 font-bold">
                  Value: {factor.value}
                </p>
                <p className="text-[0.65rem] text-[#64748b] mt-0.5">
                  SHAP Impact: {factor.impact}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Recommended Clinical Management Plan */}
        <div className="space-y-3">
          <h4 className="font-headline text-xs font-bold text-[#0b1c30] uppercase tracking-wider flex items-center gap-2">
            <CheckCircle className="size-4 text-emerald-600" />
            <span>Recommended Clinical Management &amp; Care Pathway</span>
          </h4>
          <div className="rounded-2xl border border-[#e2e8f0] bg-[#f8f9ff] p-4 space-y-2.5">
            {report.recommendations.map((rec, idx) => (
              <div key={idx} className="flex items-start gap-2.5">
                <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-white text-[0.65rem] font-bold">
                  {idx + 1}
                </span>
                <p className="leading-relaxed text-[#0b1c30]">{rec}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mandatory Clinical Disclaimer & Physician Sign-off */}
        <div className="border-t border-[#e2e8f0] pt-6 space-y-4">
          <div className="rounded-xl border border-[#e2e8f0] bg-[#f8f9ff] p-4 text-[0.7rem] text-[#64748b] flex items-start gap-3">
            <ShieldCheck className="size-5 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-[#0b1c30]">Mandatory Decision Support Disclaimer:</strong> {report.disclaimer}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-4 border-t border-[#e2e8f0]">
            <div>
              <p className="text-[0.65rem] uppercase font-bold text-[#64748b]">Digitally Verified &amp; Signed by:</p>
              <p className="font-bold text-[#0b1c30] text-xs mt-0.5">{report.doctorName}</p>
              <p className="text-[0.62rem] font-mono text-[#64748b]">License ID: {report.doctorLicense}</p>
            </div>

            <div className="border-b border-[#0b1c30] w-48 text-center pb-1">
              <span className="text-[0.65rem] font-mono text-[#64748b]">[Electronic Cryptographic Signature Verified]</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
